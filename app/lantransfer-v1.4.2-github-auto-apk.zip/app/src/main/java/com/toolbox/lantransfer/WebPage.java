package com.toolbox.lantransfer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class WebPage {
    private WebPage() {}

    public static String render(HttpServer.Host host, String okParam, String delParam) {
        List<HttpServer.Entry> shared = host.sharedFiles();
        List<HttpServer.Entry> received = host.receivedFiles();
        String saveDir = host.saveDirLabel();
        if (saveDir == null || saveDir.isEmpty()) saveDir = "Download/toolbot/局域网传输";

        StringBuilder sb = new StringBuilder(12288);
        sb.append("<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
          .append("<title>局域网文件传输</title><style>")
          .append("*,*::before,*::after{box-sizing:border-box}")
          .append(":root{--bg:#f3f5f9;--card:#fff;--text:#0f172a;--sub:#64748b;--muted:#94a3b8;--blue:#2563eb;--blue-soft:#eef2ff;--green:#16a34a;--green-soft:#dcfce7;--red:#dc2626;--red-soft:#fee2e2;--border:#e2e8f0}")
          .append("body{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;-webkit-font-smoothing:antialiased}")
          .append(".wrap{max-width:960px;margin:0 auto;padding:20px 16px 48px}")
          .append(".top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}")
          .append(".brand{display:flex;align-items:center;gap:10px}")
          .append(".badge{display:inline-flex;align-items:center;gap:6px;background:var(--green-soft);color:var(--green);font-size:12px;font-weight:600;padding:4px 10px;border-radius:999px}")
          .append(".badge i{width:7px;height:7px;border-radius:50%;background:var(--green);display:inline-block}")
          .append("h1{font-size:22px;font-weight:700;margin:0;letter-spacing:-.2px}")
          .append(".refresh{border:1px solid var(--border);background:#fff;color:var(--sub);border-radius:10px;padding:7px 12px;font-size:13px;cursor:pointer}")
          .append(".refresh:hover{border-color:var(--blue);color:var(--blue)}")
          .append(".grid{display:grid;grid-template-columns:1fr;gap:14px}")
          .append("@media(min-width:760px){.grid{grid-template-columns:1.05fr .95fr;align-items:start}}")
          .append(".card{background:var(--card);border:1px solid rgba(15,23,42,.06);border-radius:16px;padding:18px;box-shadow:0 1px 3px rgba(15,23,42,.04)}")
          .append(".shead{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:12px}")
          .append(".stitle{font-size:16px;font-weight:700;margin:0;display:flex;align-items:center;gap:8px}")
          .append(".cnt{font-size:12px;font-weight:600;color:var(--blue);background:var(--blue-soft);padding:2px 8px;border-radius:999px}")
          .append(".hint{color:var(--sub);font-size:13px;margin:0 0 12px;line-height:1.6}")
          .append(".drop{border:2px dashed #cbd5e1;border-radius:14px;padding:22px 16px;text-align:center;background:#f8fafc;cursor:pointer;transition:.15s}")
          .append(".drop:hover,.drop.over{border-color:var(--blue);background:var(--blue-soft)}")
          .append(".drop strong{display:block;font-size:15px;color:var(--text);margin-bottom:4px}")
          .append(".drop span{font-size:12px;color:var(--sub)}")
          .append("#file{display:none}")
          .append(".sel-list{margin:10px 0 0;display:flex;flex-direction:column;gap:6px}")
          .append(".sel-item{display:flex;align-items:center;justify-content:space-between;gap:8px;background:#f8fafc;border:1px solid var(--border);border-radius:10px;padding:7px 10px;font-size:13px}")
          .append(".sel-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}")
          .append(".sel-rm{border:0;background:none;color:var(--muted);cursor:pointer;font-size:16px;padding:0 4px}")
          .append(".sel-rm:hover{color:var(--red)}")
          .append(".up-actions{display:flex;gap:8px;margin-top:12px}")
          .append(".btn{flex:1;height:42px;border:0;border-radius:11px;background:var(--blue);color:#fff;font-size:14px;font-weight:600;cursor:pointer}")
          .append(".btn:disabled{opacity:.55;cursor:not-allowed}")
          .append(".btn-cancel{flex:none;height:42px;padding:0 16px;border:1px solid var(--border);border-radius:11px;background:#fff;color:var(--sub);font-size:13px;font-weight:600;cursor:pointer;display:none}")
          .append(".prog-wrap{display:none;margin-top:12px}")
          .append(".prog-bar{height:8px;background:#e2e8f0;border-radius:999px;overflow:hidden}")
          .append(".prog-fill{height:100%;width:0;background:var(--blue);transition:width .12s}")
          .append(".prog-meta{display:flex;justify-content:space-between;font-size:12px;color:var(--sub);margin-top:6px}")
          .append(".row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 0;border-bottom:1px solid #f1f5f9}")
          .append(".row:last-child{border-bottom:0;padding-bottom:2px}")
          .append(".finfo{min-width:0;flex:1}")
          .append(".fname{font-size:14px;font-weight:500;color:var(--text);word-break:break-all;line-height:1.4}")
          .append(".fmeta{font-size:12px;color:var(--muted);margin-top:2px}")
          .append(".acts{display:flex;align-items:center;gap:6px;flex:none}")
          .append(".act{display:inline-flex;align-items:center;justify-content:center;height:32px;padding:0 12px;border-radius:9px;font-size:12px;font-weight:600;text-decoration:none;border:0;cursor:pointer}")
          .append(".act-dl{background:var(--blue-soft);color:var(--blue)}")
          .append(".act-del{background:var(--red-soft);color:var(--red)}")
          .append(".clear{border:0;background:var(--red-soft);color:var(--red);font-size:12px;font-weight:600;padding:5px 10px;border-radius:8px;cursor:pointer}")
          .append(".empty{text-align:center;color:var(--muted);font-size:13px;padding:24px 0}")
          .append(".toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:10px 18px;border-radius:999px;font-size:13px;box-shadow:0 8px 24px rgba(15,23,42,.2);opacity:0;pointer-events:none;transition:opacity .2s;z-index:99}")
          .append(".toast.show{opacity:1}")
          .append(".foot{text-align:center;color:var(--muted);font-size:12px;line-height:1.8;margin-top:22px}")
          .append("</style></head><body><div class=\"wrap\">")
          .append("<div class=\"top\"><div class=\"brand\"><h1>局域网文件传输</h1><span class=\"badge\"><i></i>已连接</span></div>")
          .append("<button class=\"refresh\" type=\"button\" onclick=\"refreshLists(true)\">刷新列表</button></div>");

        if (okParam != null && !okParam.isEmpty()) {
            sb.append("<script>window.__initToast='上传完成';</script>");
        } else if (delParam != null && !delParam.isEmpty()) {
            sb.append("<script>window.__initToast='").append("all".equals(delParam) ? "已清空全部已接收文件" : "已删除该文件").append("';</script>");
        }

        sb.append("<div class=\"grid\"><div style=\"display:flex;flex-direction:column;gap:14px\">");

        // 上传卡片
        sb.append("<section class=\"card\"><div class=\"shead\"><h2 class=\"stitle\">上传文件到手机</h2></div>")
          .append("<p class=\"hint\">保存至手机 <strong>").append(esc(saveDir)).append("</strong> 目录</p>")
          .append("<form id=\"upForm\" method=\"post\" action=\"/upload\" enctype=\"multipart/form-data\">")
          .append("<label id=\"dropZone\" class=\"drop\" for=\"file\"><strong>点击选择或拖拽文件到这里</strong><span>支持多选与大文件直传</span></label>")
          .append("<input id=\"file\" type=\"file\" name=\"file\" multiple>")
          .append("<div id=\"selList\" class=\"sel-list\"></div>")
          .append("<div class=\"up-actions\"><button id=\"upBtn\" class=\"btn\" type=\"submit\">开始上传</button>")
          .append("<button id=\"cancelBtn\" class=\"btn-cancel\" type=\"button\">取消</button></div>")
          .append("<div id=\"progWrap\" class=\"prog-wrap\"><div class=\"prog-bar\"><div id=\"progFill\" class=\"prog-fill\"></div></div>")
          .append("<div class=\"prog-meta\"><span id=\"progPct\">0%</span><span id=\"progSpd\">准备中…</span></div></div>")
          .append("</form></section>");

        // 共享文件卡片
        sb.append("<section class=\"card\"><div class=\"shead\"><h2 class=\"stitle\">手机共享文件 <span id=\"sharedCnt\" class=\"cnt\">")
          .append(shared.size()).append("</span></h2></div><div id=\"sharedBox\">");
        if (shared.isEmpty()) {
            sb.append("<div class=\"empty\">暂无共享文件，请在手机端添加</div>");
        } else {
            for (HttpServer.Entry e : shared) {
                sb.append("<div class=\"row\"><div class=\"finfo\"><div class=\"fname\">").append(esc(e.name))
                  .append("</div><div class=\"fmeta\">").append(size(e.size))
                  .append("</div></div><div class=\"acts\"><a class=\"act act-dl\" href=\"/download?f=")
                  .append(HttpServer.urlEncode(e.name)).append("\">下载</a></div></div>");
            }
        }
        sb.append("</div></section></div>");

        // 右栏：已接收文件
        sb.append("<section class=\"card\"><div class=\"shead\"><h2 class=\"stitle\">已接收文件 <span id=\"recCnt\" class=\"cnt\">")
          .append(received.size()).append("</span></h2>")
          .append("<button id=\"clearRecBtn\" class=\"clear\" type=\"button\" style=\"display:")
          .append(received.isEmpty() ? "none" : "inline-block")
          .append("\" onclick=\"delFile('*')\">清空全部</button></div><div id=\"recBox\">");
        if (received.isEmpty()) {
            sb.append("<div class=\"empty\">暂无已接收文件</div>");
        } else {
            for (HttpServer.Entry e : received) {
                sb.append("<div class=\"row\"><div class=\"finfo\"><div class=\"fname\">").append(esc(e.name))
                  .append("</div><div class=\"fmeta\">").append(size(e.size)).append(" · ").append(time(e.time))
                  .append("</div></div><div class=\"acts\"><a class=\"act act-dl\" href=\"/download-received?f=")
                  .append(HttpServer.urlEncode(e.name)).append("\">下载</a>")
                  .append("<button class=\"act act-del\" type=\"button\" onclick=\"delFile(")
                  .append(jsStr(e.name)).append(")\">删除</button></div></div>");
            }
        }
        sb.append("</div></section></div>")
          .append("<p class=\"foot\">文件保存在手机 ").append(esc(saveDir))
          .append(" 目录 · 仅在同一局域网内直连传输，不经过互联网</p></div>")
          .append("<div id=\"toast\" class=\"toast\"></div>");

        // JS：空文件校验 + 拖拽上传 + XHR进度条/速率/取消 + 自动刷新
        sb.append("<script>")
          .append("var selected=[],xhr=null,toastTimer=null;")
          .append("function showToast(m){var t=document.getElementById('toast');t.textContent=m;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(function(){t.classList.remove('show');},2600);}")
          .append("if(window.__initToast)showToast(window.__initToast);")
          .append("function fmtSize(b){if(b<1024)return b+' B';if(b<1048576)return (b/1024).toFixed(1)+' KB';if(b<1073741824)return (b/1048576).toFixed(1)+' MB';return (b/1073741824).toFixed(2)+' GB';}")
          .append("function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;');}")
          .append("function renderSel(){var box=document.getElementById('selList');if(!selected.length){box.innerHTML='';return;}box.innerHTML=selected.map(function(f,i){return '<div class=\"sel-item\"><span class=\"sel-name\">'+esc(f.name)+' ('+fmtSize(f.size)+')</span><button class=\"sel-rm\" type=\"button\" onclick=\"rmSel('+i+')\">×</button></div>';}).join('');}")
          .append("function rmSel(i){selected.splice(i,1);renderSel();}")
          .append("var inp=document.getElementById('file'),dz=document.getElementById('dropZone');")
          .append("inp.addEventListener('change',function(){for(var i=0;i<inp.files.length;i++)selected.push(inp.files[i]);inp.value='';renderSel();});")
          .append("['dragenter','dragover'].forEach(function(ev){dz.addEventListener(ev,function(e){e.preventDefault();dz.classList.add('over');});});")
          .append("['dragleave','drop'].forEach(function(ev){dz.addEventListener(ev,function(e){e.preventDefault();dz.classList.remove('over');});});")
          .append("dz.addEventListener('drop',function(e){var fs=e.dataTransfer.files;for(var i=0;i<fs.length;i++)selected.push(fs[i]);renderSel();});")
          .append("document.getElementById('cancelBtn').onclick=function(){if(xhr){xhr.abort();xhr=null;}};")
          .append("document.getElementById('upForm').onsubmit=function(e){e.preventDefault();if(!selected.length){showToast('请先选择要上传的文件');return;}if(xhr)return;")
          .append("var fd=new FormData();selected.forEach(function(f){fd.append('file',f,f.name);});")
          .append("var btn=document.getElementById('upBtn'),cbtn=document.getElementById('cancelBtn'),pw=document.getElementById('progWrap'),pf=document.getElementById('progFill'),pp=document.getElementById('progPct'),ps=document.getElementById('progSpd');")
          .append("btn.disabled=true;btn.textContent='上传中…';cbtn.style.display='inline-block';pw.style.display='block';pf.style.width='0%';pp.textContent='0%';ps.textContent='连接中…';")
          .append("var t0=Date.now();xhr=new XMLHttpRequest();xhr.open('POST','/upload',true);xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');")
          .append("xhr.upload.onprogress=function(ev){if(ev.lengthComputable){var pct=Math.min(100,Math.round(ev.loaded*100/ev.total));pf.style.width=pct+'%';pp.textContent=pct+'%';var dt=(Date.now()-t0)/1000;ps.textContent=dt>0.2?fmtSize(ev.loaded/dt)+'/s':'上传中…';}};")
          .append("function resetUp(){xhr=null;btn.disabled=false;btn.textContent='开始上传';cbtn.style.display='none';setTimeout(function(){pw.style.display='none';},600);}")
          .append("xhr.onload=function(){var ok=xhr.status>=200&&xhr.status<300;try{var r=JSON.parse(xhr.responseText);if(ok&&r.ok){selected=[];renderSel();showToast('已上传 '+r.files.length+' 个文件');refreshLists(false);}else{showToast(r.error||'上传失败');}}catch(ex){showToast(ok?'上传完成':'上传失败');if(ok){selected=[];renderSel();refreshLists(false);}}resetUp();};")
          .append("xhr.onerror=function(){showToast('网络中断，上传失败');resetUp();};")
          .append("xhr.onabort=function(){showToast('已取消上传');resetUp();};")
          .append("xhr.send(fd);};")
          .append("function delFile(name){var msg=name==='*'?'确定要清空全部已接收文件？':'确定删除「'+name+'」？';if(!confirm(msg))return;")
          .append("var req=new XMLHttpRequest();req.open('POST','/delete',true);req.setRequestHeader('Content-Type','application/x-www-form-urlencoded');req.setRequestHeader('X-Requested-With','XMLHttpRequest');")
          .append("req.onload=function(){showToast(name==='*'?'已清空全部已接收文件':'已删除该文件');refreshLists(false);};")
          .append("req.send('type=received&name='+encodeURIComponent(name));}")
          .append("function refreshLists(manual){var r=new XMLHttpRequest();r.open('GET','/api/list',true);r.onload=function(){if(r.status!==200)return;try{var d=JSON.parse(r.responseText);")
          .append("document.getElementById('sharedCnt').textContent=d.shared.length;document.getElementById('recCnt').textContent=d.received.length;")
          .append("document.getElementById('clearRecBtn').style.display=d.received.length?'inline-block':'none';")
          .append("document.getElementById('sharedBox').innerHTML=d.shared.length?d.shared.map(function(e){return '<div class=\"row\"><div class=\"finfo\"><div class=\"fname\">'+esc(e.name)+'</div><div class=\"fmeta\">'+esc(e.sizeText)+'</div></div><div class=\"acts\"><a class=\"act act-dl\" href=\"'+e.url+'\">下载</a></div></div>';}).join(''):'<div class=\"empty\">暂无共享文件，请在手机端添加</div>';")
          .append("document.getElementById('recBox').innerHTML=d.received.length?d.received.map(function(e){return '<div class=\"row\"><div class=\"finfo\"><div class=\"fname\">'+esc(e.name)+'</div><div class=\"fmeta\">'+esc(e.sizeText)+' · '+esc(e.timeText)+'</div></div><div class=\"acts\"><a class=\"act act-dl\" href=\"'+e.url+'\">下载</a><button class=\"act act-del\" type=\"button\" onclick=\"delFile('+JSON.stringify(e.name)+')\">删除</button></div></div>';}).join(''):'<div class=\"empty\">暂无已接收文件</div>';")
          .append("if(manual)showToast('列表已刷新');}catch(ex){}};r.send();}")
          .append("setInterval(function(){if(!xhr)refreshLists(false);},5000);")
          .append("</script></body></html>");

        return sb.toString();
    }

    private static String jsStr(String s) {
        if (s == null) return "''";
        StringBuilder sb = new StringBuilder(s.length() + 4);
        sb.append('\'');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\') sb.append("\\\\");
            else if (c == '\'') sb.append("\\'");
            else if (c == '"') sb.append("&quot;");
            else if (c == '<') sb.append("\\x3c");
            else if (c == '>') sb.append("\\x3e");
            else sb.append(c);
        }
        sb.append('\'');
        return sb.toString();
    }

    public static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                case '\'': sb.append("&#39;"); break;
                default: sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String size(long bytes) {
        return Storage.sizeText(bytes);
    }

    public static String time(long ts) {
        if (ts <= 0) return "";
        return new SimpleDateFormat("MM-dd HH:mm", Locale.US).format(new Date(ts));
    }
}
