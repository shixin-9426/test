package com.toolbox.lantransfer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1001;
    private static final int REQ_PERM = 1002;
    private static final int REQ_TREE = 1003;

    private View statusPill;
    private View statusDot;
    private TextView statusText;
    private LinearLayout urlBox;
    private TextView urlText;
    private TextView actionBtn;
    private TextView toggleQrBtn;
    private LinearLayout qrCard;
    private ImageView qrImage;
    private TextView qrHint;

    private TextView tabSharedBtn;
    private TextView tabReceivedBtn;
    private LinearLayout panelShared;
    private LinearLayout panelReceived;

    private TextView addFileBtn;
    private TextView clearSharedBtn;
    private TextView noShared;
    private LinearLayout sharedList;

    private TextView receivedCount;
    private TextView clearReceivedBtn;
    private TextView noReceived;
    private LinearLayout receivedList;

    private TextView saveDirText;
    private TextView resetDirBtn;
    private TextView saveNote;
    private LinearLayout usageBody;
    private TextView usageArrow;

    private boolean qrExpanded = true;
    private boolean showingReceivedTab = false;
    private boolean usageExpanded = false;

    private String lastReceivedSig = "";
    private String lastUrl = "";
    private long lastIpRefresh = 0L;
    private volatile boolean destroyed = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService bgExecutor = Executors.newSingleThreadExecutor();

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            refreshStateAsync();
            refreshReceivedAsync();
            handler.postDelayed(this, 1500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusPill = findViewById(R.id.statusPill);
        statusDot = findViewById(R.id.statusDot);
        statusText = findViewById(R.id.statusText);
        urlBox = findViewById(R.id.urlBox);
        urlText = findViewById(R.id.urlText);
        actionBtn = findViewById(R.id.actionBtn);
        toggleQrBtn = findViewById(R.id.toggleQrBtn);
        qrCard = findViewById(R.id.qrCard);
        qrImage = findViewById(R.id.qrImage);
        qrHint = findViewById(R.id.qrHint);

        tabSharedBtn = findViewById(R.id.tabSharedBtn);
        tabReceivedBtn = findViewById(R.id.tabReceivedBtn);
        panelShared = findViewById(R.id.panelShared);
        panelReceived = findViewById(R.id.panelReceived);

        addFileBtn = findViewById(R.id.addFileBtn);
        clearSharedBtn = findViewById(R.id.clearSharedBtn);
        noShared = findViewById(R.id.noShared);
        sharedList = findViewById(R.id.sharedList);

        receivedCount = findViewById(R.id.receivedCount);
        clearReceivedBtn = findViewById(R.id.clearReceivedBtn);
        noReceived = findViewById(R.id.noReceived);
        receivedList = findViewById(R.id.receivedList);

        saveDirText = findViewById(R.id.saveDirText);
        resetDirBtn = findViewById(R.id.resetDirBtn);
        saveNote = findViewById(R.id.saveNote);
        usageBody = findViewById(R.id.usageBody);
        usageArrow = findViewById(R.id.usageArrow);

        findViewById(R.id.copyBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String u = urlText.getText().toString();
                if (TextUtils.isEmpty(u)) return;
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("局域网地址", u));
                    toast("地址已复制");
                }
            }
        });

        actionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LanService srv = LanService.getInstance();
                if (srv != null && srv.isRunning()) {
                    Intent stop = new Intent(MainActivity.this, LanService.class)
                            .setAction(LanService.ACTION_STOP);
                    startService(stop);
                    toast("服务已停止");
                } else {
                    requestRuntimePermissions();
                    startLanService();
                }
            }
        });

        toggleQrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qrExpanded = !qrExpanded;
                updateQrVisibility();
            }
        });

        tabSharedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(false);
            }
        });

        tabReceivedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab(true);
            }
        });

        addFileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker();
            }
        });

        clearSharedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmClearShared();
            }
        });

        clearReceivedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmClearReceived();
            }
        });

        findViewById(R.id.changeDirBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseSaveDir();
            }
        });

        resetDirBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Storage.clearCustomTree(MainActivity.this);
                refreshSaveDir();
                toast("已恢复默认保存目录");
            }
        });

        findViewById(R.id.usageHeader).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usageExpanded = !usageExpanded;
                usageBody.setVisibility(usageExpanded ? View.VISIBLE : View.GONE);
                usageArrow.setText(usageExpanded ? "收起" : "展开");
            }
        });

        switchTab(false);
        refreshSaveDir();
        refreshFiles();
        refreshStateAsync();
        refreshReceivedAsync();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        refreshFiles();
        refreshSaveDir();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        bgExecutor.shutdownNow();
        super.onDestroy();
    }

    private void switchTab(boolean received) {
        showingReceivedTab = received;
        panelShared.setVisibility(received ? View.GONE : View.VISIBLE);
        panelReceived.setVisibility(received ? View.VISIBLE : View.GONE);

        tabSharedBtn.setBackgroundResource(received ? 0 : R.drawable.bg_segment_active);
        tabSharedBtn.setTextColor(getResources().getColor(received ? R.color.text_sub : R.color.blue));
        tabReceivedBtn.setBackgroundResource(received ? R.drawable.bg_segment_active : 0);
        tabReceivedBtn.setTextColor(getResources().getColor(received ? R.color.blue : R.color.text_sub));
    }

    private void updateQrVisibility() {
        LanService srv = LanService.getInstance();
        boolean running = srv != null && srv.isRunning();
        if (!running) {
            qrCard.setVisibility(View.GONE);
            toggleQrBtn.setVisibility(View.GONE);
            return;
        }
        toggleQrBtn.setVisibility(View.VISIBLE);
        toggleQrBtn.setText(qrExpanded ? R.string.toggle_qr_hide : R.string.toggle_qr_show);
        qrCard.setVisibility(qrExpanded ? View.VISIBLE : View.GONE);
    }

    private void requestRuntimePermissions() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    private void startLanService() {
        try {
            Intent intent = new Intent(this, LanService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            toast("正在启动服务…");
        } catch (Exception e) {
            toast("启动失败：" + e.getMessage());
        }
    }

    /** 修复性能问题：将网络接口枚举与二维码生成移至后台线程，避免阻塞主线程 */
    private void refreshStateAsync() {
        final LanService srv = LanService.getInstance();
        final boolean running = srv != null && srv.isRunning();
        if (!running) {
            applyStoppedState();
            return;
        }

        final long now = System.currentTimeMillis();
        final int port = srv.getPort();
        bgExecutor.execute(new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                String ip;
                if (now - lastIpRefresh > 3000 || lastUrl.isEmpty()) {
                    ip = srv.getIp();
                    lastIpRefresh = now;
                } else {
                    int colon = lastUrl.lastIndexOf(':');
                    ip = colon > 6 ? lastUrl.substring(7, colon) : srv.getIp();
                }
                final String url = "http://" + ip + ":" + port;
                final boolean hasLan = !ip.startsWith("127.") && !ip.isEmpty();
                srv.updateNotificationIfNeeded(url);

                Bitmap bmp = null;
                final boolean urlChanged = !url.equals(lastUrl);
                if (urlChanged) {
                    bmp = QRUtil.encode(url, 520);
                }
                final Bitmap finalBmp = bmp;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) return;
                        statusPill.setBackgroundResource(R.drawable.bg_pill_on);
                        statusDot.setBackgroundResource(R.drawable.bg_dot_on);
                        statusText.setText(hasLan ? R.string.service_running : R.string.no_lan);
                        statusText.setTextColor(getResources().getColor(hasLan ? R.color.green : R.color.note_text));

                        urlBox.setVisibility(View.VISIBLE);
                        urlText.setText(url);
                        actionBtn.setText(R.string.stop_service);
                        actionBtn.setBackgroundResource(R.drawable.bg_btn_danger);
                        qrHint.setText(hasLan ? R.string.scan_hint : R.string.no_lan_hint);

                        if (urlChanged) {
                            lastUrl = url;
                            if (finalBmp != null) {
                                qrImage.setImageBitmap(finalBmp);
                            }
                        }
                        updateQrVisibility();
                    }
                });
            }
        });
    }

    private void applyStoppedState() {
        statusPill.setBackgroundResource(R.drawable.bg_pill_off);
        statusDot.setBackgroundResource(R.drawable.bg_dot_off);
        statusText.setText(R.string.service_stopped);
        statusText.setTextColor(getResources().getColor(R.color.text_sub));
        urlBox.setVisibility(View.GONE);
        actionBtn.setText(R.string.start_service);
        actionBtn.setBackgroundResource(R.drawable.bg_btn_primary);
        qrCard.setVisibility(View.GONE);
        toggleQrBtn.setVisibility(View.GONE);
        lastUrl = "";

        if (LanService.lastError != null) {
            String err = LanService.lastError;
            LanService.lastError = null;
            toast(err);
        }
    }

    /** 修复 Bug：原版默认目录下未传参数调用 getString(R.string.save_note)，导致界面直接显示 "%1$s" */
    private void refreshSaveDir() {
        boolean custom = Storage.isCustomDir(this);
        String label = Storage.saveDirLabel(this);
        saveDirText.setText(custom ? label : getString(R.string.save_dir_default));
        resetDirBtn.setVisibility(custom ? View.VISIBLE : View.GONE);
        saveNote.setText(getString(custom ? R.string.save_note_custom : R.string.save_note, label));
    }

    private void refreshFiles() {
        List<HttpServer.Entry> list = Storage.sharedEntries(this);
        tabSharedBtn.setText(getString(R.string.tab_shared, list.size()));
        addFileBtn.setText(list.isEmpty() ? R.string.add_file : R.string.add_file_more);
        clearSharedBtn.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
        noShared.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        sharedList.removeAllViews();
        for (int i = 0; i < list.size(); i++) {
            sharedList.addView(buildSharedRow(list.get(i), i == list.size() - 1));
        }
    }

    private void refreshReceivedAsync() {
        bgExecutor.execute(new Runnable() {
            @Override
            public void run() {
                if (destroyed) return;
                final List<HttpServer.Entry> list = Storage.receivedEntries(MainActivity.this);
                StringBuilder sig = new StringBuilder();
                for (HttpServer.Entry e : list) {
                    sig.append(e.name).append('|').append(e.time).append(';');
                }
                final String sigStr = sig.toString();
                if (sigStr.equals(lastReceivedSig)) return;
                lastReceivedSig = sigStr;

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) return;
                        tabReceivedBtn.setText(getString(R.string.tab_received, list.size()));
                        receivedCount.setText(getString(R.string.received_count, list.size()));
                        clearReceivedBtn.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
                        noReceived.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                        receivedList.removeAllViews();
                        for (int i = 0; i < list.size(); i++) {
                            receivedList.addView(buildReceivedRow(list.get(i), i == list.size() - 1));
                        }
                    }
                });
            }
        });
    }

    private View buildSharedRow(final HttpServer.Entry entry, boolean isLast) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        row.addView(buildExtBadge(entry.name));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        infoLp.setMarginStart(dp(10));
        info.setLayoutParams(infoLp);

        TextView nameTv = new TextView(this);
        nameTv.setText(entry.name);
        nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        nameTv.setTextColor(getResources().getColor(R.color.text_main));
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        info.addView(nameTv);

        TextView sizeTv = new TextView(this);
        sizeTv.setText(Storage.sizeText(entry.size));
        sizeTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        sizeTv.setTextColor(getResources().getColor(R.color.text_muted));
        sizeTv.setPadding(0, dp(2), 0, 0);
        info.addView(sizeTv);

        row.addView(info);

        // 优化触控热区：由原先极小的 8/2dp 扩大到 40x36dp
        TextView rm = new TextView(this);
        rm.setText("×");
        rm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        rm.setTextColor(getResources().getColor(R.color.text_muted));
        rm.setGravity(Gravity.CENTER);
        rm.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(36)));
        rm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmRemoveShared(entry.name);
            }
        });
        row.addView(rm);

        outer.addView(row);
        if (!isLast) {
            outer.addView(buildDivider());
        }
        return outer;
    }

    private View buildReceivedRow(final HttpServer.Entry entry, boolean isLast) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        row.addView(buildExtBadge(entry.name));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        infoLp.setMarginStart(dp(10));
        info.setLayoutParams(infoLp);

        TextView nameTv = new TextView(this);
        nameTv.setText(entry.name);
        nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        nameTv.setTextColor(getResources().getColor(R.color.text_main));
        nameTv.setMaxLines(2);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(nameTv);

        TextView metaTv = new TextView(this);
        metaTv.setText(Storage.sizeText(entry.size) + " · " + timeText(entry.time));
        metaTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        metaTv.setTextColor(getResources().getColor(R.color.text_muted));
        metaTv.setPadding(0, dp(2), 0, 0);
        info.addView(metaTv);

        row.addView(info);

        boolean isApk = entry.name.toLowerCase(Locale.US).endsWith(".apk");
        TextView openBtn = new TextView(this);
        openBtn.setText(isApk ? R.string.action_install : R.string.action_open);
        openBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        openBtn.setTypeface(null, Typeface.BOLD);
        openBtn.setTextColor(getResources().getColor(R.color.blue));
        openBtn.setBackgroundResource(R.drawable.bg_btn_soft);
        openBtn.setGravity(Gravity.CENTER);
        openBtn.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        openLp.setMarginStart(dp(8));
        openBtn.setLayoutParams(openLp);
        openBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openReceived(entry);
            }
        });
        row.addView(openBtn);

        // 新增：手机端单条删除按钮（与网页端功能对称）
        TextView delBtn = new TextView(this);
        delBtn.setText(R.string.action_delete);
        delBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        delBtn.setTypeface(null, Typeface.BOLD);
        delBtn.setTextColor(getResources().getColor(R.color.red));
        delBtn.setBackgroundResource(R.drawable.bg_btn_danger_soft);
        delBtn.setGravity(Gravity.CENTER);
        delBtn.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        delLp.setMarginStart(dp(6));
        delBtn.setLayoutParams(delLp);
        delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDeleteReceived(entry.name);
            }
        });
        row.addView(delBtn);

        outer.addView(row);
        if (!isLast) {
            outer.addView(buildDivider());
        }
        return outer;
    }

    private View buildExtBadge(String filename) {
        int dot = filename.lastIndexOf('.');
        String ext = (dot >= 0 && dot < filename.length() - 1)
                ? filename.substring(dot + 1).toUpperCase(Locale.US)
                : "FILE";
        if (ext.length() > 4) ext = ext.substring(0, 4);
        TextView tv = new TextView(this);
        tv.setText(ext);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(getResources().getColor(R.color.blue));
        tv.setBackgroundResource(R.drawable.bg_ext_badge);
        tv.setGravity(Gravity.CENTER);
        tv.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        return tv;
    }

    private View buildDivider() {
        View div = new View(this);
        div.setBackgroundColor(getResources().getColor(R.color.divider));
        div.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(1))));
        return div;
    }

    private void openReceived(HttpServer.Entry entry) {
        Uri uri = Storage.receivedContentUri(this, entry.name);
        if (uri == null) {
            toast(getString(R.string.file_missing));
            return;
        }
        boolean isApk = entry.name.toLowerCase(Locale.US).endsWith(".apk");
        if (isApk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !getPackageManager().canRequestPackageInstalls()) {
            askInstallPermission();
            return;
        }
        String mime = isApk ? "application/vnd.android.package-archive" : Storage.mimeOf(entry.name);
        Intent viewIntent = new Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(viewIntent);
        } catch (Exception e) {
            if (isApk) {
                // 修复 Bug：为回退安装 Intent 补充 try-catch，避免无安装器或权限异常时直接闪退
                try {
                    Intent installIntent = new Intent(Intent.ACTION_INSTALL_PACKAGE)
                            .setDataAndType(uri, mime)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(installIntent);
                } catch (Exception ex) {
                    toast(getString(R.string.no_app_open));
                }
            } else {
                toast(getString(R.string.no_app_open));
            }
        }
    }

    private void askInstallPermission() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.install_permission_title)
                .setMessage(R.string.install_permission_msg)
                .setNegativeButton("取消", null)
                .setPositiveButton(R.string.goto_settings, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            startActivity(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES",
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            toast("请到系统设置里允许安装未知来源应用");
                        }
                    }
                })
                .show();
    }

    private void openPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*")
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(intent, REQ_PICK);
        } catch (Exception e) {
            toast("没有找到可用的文件选择器");
        }
    }

    private void chooseSaveDir() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, REQ_TREE);
        } catch (Exception e) {
            toast("系统没有可用的文件选择器");
        }
    }

    private void confirmClearShared() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.clear_title)
                .setMessage(R.string.clear_msg)
                .setNegativeButton("取消", null)
                .setPositiveButton(R.string.clear_action, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Storage.clearShared(MainActivity.this);
                        refreshFiles();
                        toast(getString(R.string.cleared));
                    }
                })
                .show();
    }

    private void confirmRemoveShared(final String name) {
        new AlertDialog.Builder(this)
                .setTitle("移除共享文件")
                .setMessage(name)
                .setNegativeButton("取消", null)
                .setPositiveButton("移除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Storage.removeShared(MainActivity.this, name);
                        refreshFiles();
                    }
                })
                .show();
    }

    private void confirmDeleteReceived(final String name) {
        new AlertDialog.Builder(this)
                .setTitle("删除已接收文件")
                .setMessage("确定删除「" + name + "」？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        bgExecutor.execute(new Runnable() {
                            @Override
                            public void run() {
                                Storage.deleteReceived(MainActivity.this, name);
                                lastReceivedSig = "";
                                refreshReceivedAsync();
                            }
                        });
                    }
                })
                .show();
    }

    private void confirmClearReceived() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.clear_received_title)
                .setMessage(R.string.clear_received_msg)
                .setNegativeButton("取消", null)
                .setPositiveButton(R.string.clear_action, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        bgExecutor.execute(new Runnable() {
                            @Override
                            public void run() {
                                Storage.clearReceived(MainActivity.this);
                                lastReceivedSig = "";
                                refreshReceivedAsync();
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (!destroyed) toast(getString(R.string.cleared_received));
                                    }
                                });
                            }
                        });
                    }
                })
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_TREE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                if (Storage.setCustomTree(this, data.getData())) {
                    refreshSaveDir();
                    toast(getString(R.string.dir_changed));
                } else {
                    toast(getString(R.string.dir_fail));
                }
            }
            return;
        }
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null) {
            final List<Uri> uris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri u = clip.getItemAt(i).getUri();
                    if (u != null) uris.add(u);
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (uris.isEmpty()) return;
            toast("正在添加文件…");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int done = 0;
                    String error = null;
                    for (Uri u : uris) {
                        try {
                            Storage.importUri(MainActivity.this, u);
                            done++;
                        } catch (Exception e) {
                            error = e.getMessage();
                        }
                    }
                    final int finalDone = done;
                    final String finalErr = error;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (destroyed) return;
                            refreshFiles();
                            if (finalDone > 0) {
                                toast("已添加 " + finalDone + " 个文件");
                            } else {
                                toast("添加失败：" + (finalErr == null ? "未知错误" : finalErr));
                            }
                        }
                    });
                }
            }, "import-files").start();
        }
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private String timeText(long ts) {
        if (ts <= 0) return "";
        return new SimpleDateFormat("MM-dd HH:mm", Locale.US).format(new Date(ts));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
