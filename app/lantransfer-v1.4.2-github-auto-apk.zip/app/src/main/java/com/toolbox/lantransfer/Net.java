package com.toolbox.lantransfer;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;

public final class Net {
    private Net() {}

    public static String localIp() {
        String bestIp = null;
        int bestScore = -1;
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return "127.0.0.1";
            for (NetworkInterface nif : Collections.list(ifaces)) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                String name = nif.getName();
                String lower = name == null ? "" : name.toLowerCase(Locale.US);
                if (lower.startsWith("tun") || lower.startsWith("rmnet")
                        || lower.startsWith("ccmni") || lower.startsWith("p2p")
                        || lower.startsWith("dummy")) {
                    continue;
                }
                for (InetAddress addr : Collections.list(nif.getInetAddresses())) {
                    if (!(addr instanceof Inet4Address) || !addr.isSiteLocalAddress()) continue;
                    int score;
                    if (lower.startsWith("wlan")) score = 5;
                    else if (lower.startsWith("ap") || lower.startsWith("swlan")) score = 4;
                    else if (lower.startsWith("eth")) score = 3;
                    else score = 1;
                    if (score > bestScore) {
                        bestScore = score;
                        bestIp = addr.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return bestIp != null ? bestIp : "127.0.0.1";
    }
}
