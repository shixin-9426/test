package com.toolbox.lantransfer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HttpServer {

    public static class Entry {
        public final String name;
        public final long size;
        public final long time;
        public final File file;

        public Entry(String name, long size, long time, File file) {
            this.name = name;
            this.size = size;
            this.time = time;
            this.file = file;
        }
    }

    public interface Host {
        List<Entry> sharedFiles();
        List<Entry> receivedFiles();
        String saveDirLabel();
        String saveUpload(InputStream in, String filename) throws IOException;
        boolean deleteReceived(String name);
        int clearReceived();
        InputStream openReceivedStream(String name) throws IOException;
        long receivedFileSize(String name);
    }

    private int port;
    private final Host host;
    private volatile boolean running;
    private ServerSocket serverSocket;
    private ExecutorService pool;
    private Thread acceptThread;

    public HttpServer(int port, Host host) {
        this.port = port;
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public boolean isRunning() {
        return running;
    }

    public synchronized boolean start() {
        if (running) return true;
        ServerSocket ss = null;
        int chosenPort = -1;
        for (int p = port; p < port + 30; p++) {
            ServerSocket cand = null;
            try {
                cand = new ServerSocket();
                cand.setReuseAddress(true);
                cand.bind(new InetSocketAddress(p), 50);
                ss = cand;
                chosenPort = p;
                break;
            } catch (IOException e) {
                if (cand != null) {
                    try { cand.close(); } catch (IOException ignored) {}
                }
            }
        }
        if (ss == null) return false;

        this.serverSocket = ss;
        this.port = chosenPort;
        this.running = true;
        this.pool = Executors.newCachedThreadPool();
        this.acceptThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    try {
                        final Socket sock = serverSocket.accept();
                        pool.execute(new Runnable() {
                            @Override
                            public void run() {
                                handle(sock);
                            }
                        });
                    } catch (IOException e) {
                        if (!running) break;
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }
        }, "lan-accept");
        this.acceptThread.start();
        return true;
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (IOException ignored) {}
            serverSocket = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
        acceptThread = null;
    }

    private void handle(Socket socket) {
        try (Socket s = socket) {
            s.setSoTimeout(180_000);
            BufferedInputStream in = new BufferedInputStream(s.getInputStream(), 16384);
            BufferedOutputStream out = new BufferedOutputStream(s.getOutputStream(), 16384);
            boolean keepAlive = true;

            while (running && keepAlive) {
                String line = readLine(in);
                if (line == null) break;
                if (line.isEmpty()) continue;

                String[] parts = line.split(" ");
                if (parts.length < 2) break;
                String method = parts[0];
                String rawTarget = parts[1];
                String proto = parts.length > 2 ? parts[2] : "";

                Map<String, String> headers = readHeaders(in);
                long contentLen = parseLong(headers.get("content-length"), 0L);
                String conn = headers.get("connection");
                keepAlive = !"close".equalsIgnoreCase(conn) && "HTTP/1.1".equalsIgnoreCase(proto);

                String rawPath = rawTarget;
                String rawQuery = null;
                int q = rawTarget.indexOf('?');
                if (q >= 0) {
                    rawPath = rawTarget.substring(0, q);
                    rawQuery = rawTarget.substring(q + 1);
                }
                String path = rawPath;
                Map<String, String> query = parseQuery(rawQuery);
                boolean isXhr = "XMLHttpRequest".equalsIgnoreCase(headers.get("x-requested-with"));

                if ("POST".equals(method) && "/upload".equals(path)) {
                    handleUpload(in, out, headers.get("content-type"), isXhr);
                    keepAlive = false;
                } else if ("POST".equals(method) && "/delete".equals(path)) {
                    handleDelete(in, out, contentLen, isXhr);
                    keepAlive = false;
                } else if ("GET".equals(method) && ("/".equals(path) || "/index.html".equals(path))) {
                    String html = WebPage.render(host, query.get("ok"), query.get("del"));
                    byte[] body = html.getBytes(StandardCharsets.UTF_8);
                    writeHeaders(out, "200 OK", "text/html; charset=utf-8", body.length, keepAlive, null);
                    out.write(body);
                } else if ("GET".equals(method) && "/api/list".equals(path)) {
                    String json = buildListJson();
                    byte[] body = json.getBytes(StandardCharsets.UTF_8);
                    writeHeaders(out, "200 OK", "application/json; charset=utf-8", body.length, keepAlive, null);
                    out.write(body);
                } else if ("GET".equals(method) && "/download".equals(path)) {
                    keepAlive = serveDownload(out, keepAlive, query.get("f"), headers.get("range"));
                } else if ("GET".equals(method) && "/download-received".equals(path)) {
                    keepAlive = serveReceivedDownload(out, query.get("f"));
                } else if ("GET".equals(method) && "/favicon.ico".equals(path)) {
                    writeHeaders(out, "204 No Content", null, 0, keepAlive, null);
                } else {
                    byte[] body = "404 Not Found".getBytes(StandardCharsets.UTF_8);
                    writeHeaders(out, "404 Not Found", "text/plain; charset=utf-8", body.length, keepAlive, null);
                    out.write(body);
                }
                out.flush();
            }
        } catch (IOException ignored) {
        }
    }

    private String buildListJson() {
        StringBuilder sb = new StringBuilder(1024);
        sb.append("{\"saveDir\":\"").append(jsonEsc(host.saveDirLabel())).append("\",\"shared\":[");
        List<Entry> shared = host.sharedFiles();
        for (int i = 0; i < shared.size(); i++) {
            Entry e = shared.get(i);
            if (i > 0) sb.append(',');
            sb.append("{\"name\":\"").append(jsonEsc(e.name))
              .append("\",\"size\":").append(e.size)
              .append(",\"sizeText\":\"").append(jsonEsc(WebPage.size(e.size)))
              .append("\",\"url\":\"/download?f=").append(urlEncode(e.name)).append("\"}");
        }
        sb.append("],\"received\":[");
        List<Entry> rec = host.receivedFiles();
        for (int i = 0; i < rec.size(); i++) {
            Entry e = rec.get(i);
            if (i > 0) sb.append(',');
            sb.append("{\"name\":\"").append(jsonEsc(e.name))
              .append("\",\"size\":").append(e.size)
              .append(",\"sizeText\":\"").append(jsonEsc(WebPage.size(e.size)))
              .append("\",\"timeText\":\"").append(jsonEsc(WebPage.time(e.time)))
              .append("\",\"url\":\"/download-received?f=").append(urlEncode(e.name)).append("\"}");
        }
        sb.append("]}");
        return sb.toString();
    }

    private static String jsonEsc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format(Locale.US, "\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.toString();
    }

    private boolean serveDownload(OutputStream out, boolean keepAlive, String filename, String rangeHeader) throws IOException {
        if (filename == null || filename.isEmpty()) {
            byte[] body = "缺少文件名".getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, "400 Bad Request", "text/plain; charset=utf-8", body.length, keepAlive, null);
            out.write(body);
            return keepAlive;
        }
        Entry found = null;
        for (Entry e : host.sharedFiles()) {
            if (e.name.equals(filename)) {
                found = e;
                break;
            }
        }
        if (found == null || found.file == null || !found.file.isFile()) {
            byte[] body = "文件不存在".getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, "404 Not Found", "text/plain; charset=utf-8", body.length, keepAlive, null);
            out.write(body);
            return keepAlive;
        }

        long totalLen = found.file.length();
        String mime = guessType(found.name);
        // 修复 Bug：调用 asciiName() 避免中文文件名在 HTTP 头中按 ISO-8859-1 解析乱码
        String disp = "attachment; filename=\"" + asciiName(found.name)
                + "\"; filename*=UTF-8''" + urlEncode(found.name);

        long start = 0;
        long end = totalLen - 1;
        boolean partial = false;

        if (rangeHeader != null && rangeHeader.toLowerCase(Locale.US).startsWith("bytes=") && totalLen > 0) {
            String spec = rangeHeader.substring(6).trim();
            int comma = spec.indexOf(',');
            if (comma >= 0) spec = spec.substring(0, comma).trim();
            int dash = spec.indexOf('-');
            if (dash >= 0) {
                String sPart = spec.substring(0, dash).trim();
                String ePart = spec.substring(dash + 1).trim();
                if (!sPart.isEmpty()) {
                    start = parseLong(sPart, 0);
                    end = ePart.isEmpty() ? totalLen - 1 : Math.min(parseLong(ePart, totalLen - 1), totalLen - 1);
                    partial = true;
                } else if (!ePart.isEmpty()) {
                    long suffix = parseLong(ePart, 0);
                    start = Math.max(0, totalLen - suffix);
                    end = totalLen - 1;
                    partial = true;
                }
            }
        }

        if (partial && (start < 0 || start >= totalLen || end < start)) {
            writeHeaders(out, "416 Range Not Satisfiable", "text/plain; charset=utf-8", 0, keepAlive,
                    "Content-Range: bytes */" + totalLen + "\r\n");
            return keepAlive;
        }

        long sendLen = totalLen == 0 ? 0 : (end - start + 1);
        StringBuilder extra = new StringBuilder();
        extra.append("Accept-Ranges: bytes\r\n");
        extra.append("Content-Disposition: ").append(disp).append("\r\n");
        if (partial) {
            extra.append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(totalLen).append("\r\n");
            writeHeaders(out, "206 Partial Content", mime, sendLen, keepAlive, extra.toString());
        } else {
            writeHeaders(out, "200 OK", mime, sendLen, keepAlive, extra.toString());
        }

        if (sendLen > 0) {
            try (RandomAccessFile raf = new RandomAccessFile(found.file, "r")) {
                raf.seek(start);
                byte[] buf = new byte[32768];
                long remaining = sendLen;
                while (remaining > 0) {
                    int n = raf.read(buf, 0, (int) Math.min(buf.length, remaining));
                    if (n <= 0) break;
                    out.write(buf, 0, n);
                    remaining -= n;
                }
            }
        }
        return keepAlive;
    }

    private boolean serveReceivedDownload(OutputStream out, String filename) throws IOException {
        if (filename == null || filename.isEmpty()) {
            byte[] body = "缺少文件名".getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, "400 Bad Request", "text/plain; charset=utf-8", body.length, false, null);
            out.write(body);
            return false;
        }
        try (InputStream in = host.openReceivedStream(filename)) {
            if (in == null) {
                byte[] body = "文件不存在".getBytes(StandardCharsets.UTF_8);
                writeHeaders(out, "404 Not Found", "text/plain; charset=utf-8", body.length, false, null);
                out.write(body);
                return false;
            }
            long sz = host.receivedFileSize(filename);
            String disp = "attachment; filename=\"" + asciiName(filename)
                    + "\"; filename*=UTF-8''" + urlEncode(filename);
            writeHeaders(out, "200 OK", guessType(filename), sz >= 0 ? sz : -1, false,
                    "Content-Disposition: " + disp + "\r\n");
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
        return false;
    }

    private void handleDelete(InputStream in, OutputStream out, long contentLen, boolean isXhr) throws IOException {
        Map<String, String> form = readForm(in, contentLen);
        String type = form.get("type");
        String name = form.get("name");
        String delTag = "one";
        if ("received".equals(type)) {
            if (name == null || name.isEmpty() || "*".equals(name)) {
                host.clearReceived();
                delTag = "all";
            } else {
                host.deleteReceived(name);
            }
        }
        if (isXhr) {
            byte[] body = ("{\"ok\":true,\"del\":\"" + delTag + "\"}").getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, "200 OK", "application/json; charset=utf-8", body.length, false, null);
            out.write(body);
        } else {
            writeHeaders(out, "303 See Other", "text/html; charset=utf-8", 0, false,
                    "Location: /?del=" + delTag + "\r\n");
        }
    }

    private void handleUpload(InputStream in, OutputStream out, String contentType, boolean isXhr) throws IOException {
        String boundary = null;
        if (contentType != null) {
            for (String part : contentType.split(";")) {
                String trimmed = part.trim();
                // 修复 Bug：boundary 参数名不区分大小写
                if (trimmed.toLowerCase(Locale.US).startsWith("boundary=")) {
                    boundary = trimmed.substring(9).trim();
                    if (boundary.length() > 1 && boundary.startsWith("\"") && boundary.endsWith("\"")) {
                        boundary = boundary.substring(1, boundary.length() - 1);
                    }
                }
            }
        }
        if (boundary == null || boundary.isEmpty()) {
            sendError(out, "400 Bad Request", "上传请求格式错误", isXhr);
            return;
        }

        byte[] startPat = ("--" + boundary).getBytes(StandardCharsets.UTF_8);
        byte[] nextPat = ("\r\n--" + boundary).getBytes(StandardCharsets.UTF_8);

        BoundaryStream first = new BoundaryStream(in, startPat);
        drainStream(first);
        InputStream stream = first.tail();

        List<String> saved = new ArrayList<>();
        boolean failed = false;
        String errMsg = "上传失败";

        try {
            while (true) {
                int b1 = stream.read();
                int b2 = stream.read();
                if (b1 < 0) break;
                if (b1 == '-' && b2 == '-') break;
                if (b1 != '\r' || b2 != '\n') break;

                Map<String, String> partHeaders = readHeaders(stream);
                String filename = extractFilename(partHeaders.get("content-disposition"));
                BoundaryStream partStream = new BoundaryStream(stream, nextPat);

                if (filename != null && !filename.trim().isEmpty()) {
                    try {
                        String savedName = host.saveUpload(partStream, filename);
                        saved.add(savedName);
                        drainStream(partStream);
                        stream = partStream.tail();
                    } catch (IOException e) {
                        errMsg = e.getMessage() != null ? e.getMessage() : "保存失败";
                        drainStream(partStream);
                        partStream.tail();
                        failed = true;
                        break;
                    }
                } else {
                    drainStream(partStream);
                    stream = partStream.tail();
                }
            }
        } catch (IOException e) {
            sendError(out, "400 Bad Request", "上传请求读取失败", isXhr);
            return;
        }

        if (failed) {
            sendError(out, "500 Internal Server Error", "上传失败：" + errMsg, isXhr);
            return;
        }

        if (isXhr) {
            StringBuilder json = new StringBuilder("{\"ok\":true,\"files\":[");
            for (int i = 0; i < saved.size(); i++) {
                if (i > 0) json.append(',');
                json.append('"').append(jsonEsc(saved.get(i))).append('"');
            }
            json.append("]}");
            byte[] body = json.toString().getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, "200 OK", "application/json; charset=utf-8", body.length, false, null);
            out.write(body);
        } else {
            StringBuilder joined = new StringBuilder();
            for (String s : saved) {
                if (joined.length() > 0) joined.append('|');
                joined.append(s);
            }
            String loc = "/?ok=" + urlEncode(joined.toString());
            writeHeaders(out, "303 See Other", "text/html; charset=utf-8", 0, false,
                    "Location: " + loc + "\r\n");
        }
    }

    private void sendError(OutputStream out, String status, String msg, boolean isXhr) throws IOException {
        if (isXhr) {
            byte[] body = ("{\"ok\":false,\"error\":\"" + jsonEsc(msg) + "\"}").getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, status, "application/json; charset=utf-8", body.length, false, null);
            out.write(body);
        } else {
            byte[] body = msg.getBytes(StandardCharsets.UTF_8);
            writeHeaders(out, status, "text/plain; charset=utf-8", body.length, false, null);
            out.write(body);
        }
    }

    /** 修复性能问题：使用缓冲区排空流，避免逐字节 read() */
    private static void drainStream(InputStream in) throws IOException {
        byte[] buf = new byte[8192];
        while (in.read(buf) != -1) {
            // discard
        }
    }

    private void writeHeaders(OutputStream out, String status, String contentType, long contentLen,
                              boolean keepAlive, String extraHeaders) throws IOException {
        StringBuilder sb = new StringBuilder(256);
        sb.append("HTTP/1.1 ").append(status).append("\r\n");
        sb.append("Date: ").append(httpDate()).append("\r\n");
        sb.append("Server: LanTransfer\r\n");
        if (contentType != null) {
            sb.append("Content-Type: ").append(contentType).append("\r\n");
        }
        if (contentLen >= 0) {
            sb.append("Content-Length: ").append(contentLen).append("\r\n");
        }
        sb.append("Connection: ").append(keepAlive ? "keep-alive" : "close").append("\r\n");
        sb.append("Cache-Control: no-store\r\n");
        if (extraHeaders != null) {
            sb.append(extraHeaders);
        }
        sb.append("\r\n");
        out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static Map<String, String> readHeaders(InputStream in) throws IOException {
        Map<String, String> map = new LinkedHashMap<>();
        String line;
        while ((line = readLine(in)) != null && !line.isEmpty()) {
            int colon = line.indexOf(':');
            if (colon > 0) {
                String k = line.substring(0, colon).trim().toLowerCase(Locale.US);
                String v = line.substring(colon + 1).trim();
                map.put(k, v);
            }
        }
        return map;
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(128);
        boolean readAny = false;
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') {
                byte[] arr = baos.toByteArray();
                int len = arr.length;
                if (len > 0 && arr[len - 1] == '\r') len--;
                return new String(arr, 0, len, StandardCharsets.UTF_8);
            }
            baos.write(b);
            readAny = true;
            if (baos.size() > 16384) break;
        }
        if (!readAny) return null;
        return new String(baos.toByteArray(), StandardCharsets.UTF_8);
    }

    private static Map<String, String> readForm(InputStream in, long contentLen) throws IOException {
        if (contentLen <= 0 || contentLen > 2 * 1024 * 1024) {
            return new LinkedHashMap<>();
        }
        int total = (int) contentLen;
        byte[] buf = new byte[total];
        int read = 0;
        while (read < total) {
            int n = in.read(buf, read, total - read);
            if (n <= 0) break;
            read += n;
        }
        return parseQuery(new String(buf, 0, read, StandardCharsets.UTF_8));
    }

    private static Map<String, String> parseQuery(String qs) {
        Map<String, String> map = new LinkedHashMap<>();
        if (qs == null || qs.isEmpty()) return map;
        for (String pair : qs.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) continue;
            try {
                String k = URLDecoder.decode(pair.substring(0, eq), "UTF-8");
                String v = URLDecoder.decode(pair.substring(eq + 1), "UTF-8");
                map.put(k, v);
            } catch (Exception ignored) {
            }
        }
        return map;
    }

    private static String extractFilename(String disp) {
        if (disp == null) return null;
        int idx = disp.indexOf("filename*=");
        if (idx >= 0) {
            String v = disp.substring(idx + 10);
            int semi = v.indexOf(';');
            if (semi >= 0) v = v.substring(0, semi);
            v = v.trim();
            if (v.length() > 1 && v.startsWith("\"") && v.endsWith("\"")) {
                v = v.substring(1, v.length() - 1);
            }
            int qq = v.indexOf("''");
            if (qq >= 0) v = v.substring(qq + 2);
            try {
                return URLDecoder.decode(v, "UTF-8");
            } catch (Exception ignored) {
                return v;
            }
        }
        idx = disp.indexOf("filename=");
        if (idx >= 0) {
            String v = disp.substring(idx + 9).trim();
            int semi = v.indexOf(';');
            if (semi >= 0) v = v.substring(0, semi);
            v = v.trim();
            if (v.length() > 1 && v.startsWith("\"") && v.endsWith("\"")) {
                v = v.substring(1, v.length() - 1);
            }
            return v;
        }
        return null;
    }

    private static String asciiName(String name) {
        StringBuilder sb = new StringBuilder();
        for (char c : name.toCharArray()) {
            if (c >= 32 && c < 127 && c != '"' && c != '\\') {
                sb.append(c);
            } else {
                sb.append('_');
            }
        }
        return sb.length() == 0 ? "file" : sb.toString();
    }

    public static String urlEncode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8").replace("+", "%20");
        } catch (Exception e) {
            return s;
        }
    }

    private static long parseLong(String s, long def) {
        if (s == null) return def;
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static String httpDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return sdf.format(new Date());
    }

    private static String guessType(String name) {
        String lower = name.toLowerCase(Locale.US);
        int dot = lower.lastIndexOf('.');
        String ext = dot >= 0 ? lower.substring(dot + 1) : "";
        switch (ext) {
            case "txt": case "md": return "text/plain; charset=utf-8";
            case "html": return "text/html; charset=utf-8";
            case "json": return "application/json; charset=utf-8";
            case "jpg": case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "bmp": return "image/bmp";
            case "mp4": return "video/mp4";
            case "mp3": return "audio/mpeg";
            case "wav": return "audio/wav";
            case "pdf": return "application/pdf";
            case "zip": return "application/zip";
            case "apk": return "application/vnd.android.package-archive";
            default: return "application/octet-stream";
        }
    }

    static class BoundaryStream extends InputStream {
        private final InputStream in;
        private final byte[] pattern;
        private final byte[] buf;
        private int start = 0;
        private int end = 0;
        private boolean eof = false;
        private boolean finished = false;

        BoundaryStream(InputStream in, byte[] pattern) {
            this.in = in;
            this.pattern = pattern;
            this.buf = new byte[Math.max(16384, pattern.length * 4)];
        }

        private boolean fill() throws IOException {
            if (eof) return false;
            if (start > 0) {
                int len = end - start;
                System.arraycopy(buf, start, buf, 0, len);
                start = 0;
                end = len;
            }
            if (end >= buf.length) return false;
            int n = in.read(buf, end, buf.length - end);
            if (n <= 0) {
                eof = true;
                return false;
            }
            end += n;
            return true;
        }

        private int indexOfPattern() {
            int max = end - pattern.length;
            for (int i = start; i <= max; i++) {
                if (buf[i] != pattern[0]) continue;
                boolean ok = true;
                for (int j = 1; j < pattern.length; j++) {
                    if (buf[i + j] != pattern[j]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) return i;
            }
            return -1;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n <= 0 ? -1 : (one[0] & 0xFF);
        }

        @Override
        public int read(byte[] out, int off, int len) throws IOException {
            if (finished) return -1;
            if (len <= 0) return 0;

            for (int guard = 0; guard < 100_000; guard++) {
                while (end - start <= pattern.length && !eof) {
                    if (!fill()) break;
                }
                int idx = indexOfPattern();
                if (idx >= 0) {
                    int avail = idx - start;
                    if (avail > 0) {
                        int n = Math.min(avail, len);
                        System.arraycopy(buf, start, out, off, n);
                        start += n;
                        return n;
                    }
                    start = idx + pattern.length;
                    finished = true;
                    return -1;
                }
                int safe = (end - (pattern.length - 1)) - start;
                if (safe > 0) {
                    int n = Math.min(safe, len);
                    System.arraycopy(buf, start, out, off, n);
                    start += n;
                    return n;
                }
                if (eof || !fill()) {
                    int rem = end - start;
                    if (rem > 0) {
                        int n = Math.min(rem, len);
                        System.arraycopy(buf, start, out, off, n);
                        start += n;
                        return n;
                    }
                    finished = true;
                    return -1;
                }
            }
            finished = true;
            return -1;
        }

        @Override
        public void close() {}

        InputStream tail() {
            finished = true;
            return new TailStream(in, buf, start, end);
        }

        static class TailStream extends InputStream {
            private final InputStream in;
            private final byte[] buf;
            private int pos;
            private final int end;
            private boolean eof = false;

            TailStream(InputStream in, byte[] buf, int pos, int end) {
                this.in = in;
                this.buf = buf;
                this.pos = pos;
                this.end = end;
            }

            @Override
            public int read() throws IOException {
                byte[] one = new byte[1];
                int n = read(one, 0, 1);
                return n <= 0 ? -1 : (one[0] & 0xFF);
            }

            @Override
            public int read(byte[] out, int off, int len) throws IOException {
                if (len <= 0) return 0;
                if (pos < end) {
                    int n = Math.min(len, end - pos);
                    System.arraycopy(buf, pos, out, off, n);
                    pos += n;
                    return n;
                }
                if (eof) return -1;
                int n = in.read(out, off, len);
                if (n <= 0) eof = true;
                return n;
            }
        }
    }
}
