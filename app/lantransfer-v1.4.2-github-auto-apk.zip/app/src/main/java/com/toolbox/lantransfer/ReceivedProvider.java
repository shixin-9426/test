package com.toolbox.lantransfer;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReceivedProvider extends ContentProvider {

    public static Uri uriFor(String name) {
        return Uri.parse("content://com.toolbox.lantransfer.received/" + Uri.encode(name));
    }

    /** 修复安全漏洞：校验规范路径，防止 ../ 路径穿越读取目录外文件 */
    private static File resolveSafeFile(Uri uri) throws FileNotFoundException {
        String raw = uri == null ? null : uri.getLastPathSegment();
        if (raw == null || raw.isEmpty()) {
            throw new FileNotFoundException("empty name");
        }
        String safeName = Storage.sanitize(raw);
        File baseDir = Storage.defaultReceivedDir();
        File target = new File(baseDir, safeName);
        try {
            String baseCanonical = baseDir.getCanonicalPath();
            String targetCanonical = target.getCanonicalPath();
            if (!targetCanonical.startsWith(baseCanonical + File.separator)) {
                throw new FileNotFoundException("invalid path");
            }
        } catch (IOException e) {
            throw new FileNotFoundException("invalid path");
        }
        if (!target.isFile()) {
            throw new FileNotFoundException(safeName);
        }
        return target;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        MatrixCursor cursor = new MatrixCursor(new String[]{"_display_name", "_size"});
        try {
            File f = resolveSafeFile(uri);
            cursor.addRow(new Object[]{f.getName(), f.length()});
        } catch (FileNotFoundException ignored) {
        }
        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        String name = uri == null ? null : uri.getLastPathSegment();
        return name == null ? "application/octet-stream" : Storage.mimeOf(name);
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolveSafeFile(uri);
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
