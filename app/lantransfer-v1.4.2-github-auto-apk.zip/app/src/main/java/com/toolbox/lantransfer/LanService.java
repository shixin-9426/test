package com.toolbox.lantransfer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class LanService extends Service {
    public static final String ACTION_STOP = "com.toolbox.lantransfer.action.STOP";
    private static final String CHANNEL_ID = "lan_transfer";
    private static final int NOTIF_ID = 1001;

    private static volatile LanService instance;
    public static volatile String lastError;

    private HttpServer server;
    private String lastNotifUrl = "";

    public static LanService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        ensureForeground(null);
        ensureServer();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (server != null) {
            server.stop();
            server = null;
        }
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public boolean isRunning() {
        return server != null && server.isRunning();
    }

    public int getPort() {
        return server == null ? 0 : server.getPort();
    }

    public String getIp() {
        return Net.localIp();
    }

    /** 修复：Wi-Fi 切换导致 IP 变化时同步更新前台通知栏地址 */
    public void updateNotificationIfNeeded(String url) {
        if (!isRunning() || url == null || url.equals(lastNotifUrl)) return;
        ensureForeground(url);
    }

    private void ensureServer() {
        if (server != null && server.isRunning()) {
            ensureForeground("http://" + getIp() + ":" + getPort());
            return;
        }
        HttpServer srv = new HttpServer(8080, new HttpServer.Host() {
            @Override
            public List<HttpServer.Entry> sharedFiles() {
                return Storage.sharedEntries(LanService.this);
            }

            @Override
            public List<HttpServer.Entry> receivedFiles() {
                return Storage.receivedEntries(LanService.this);
            }

            @Override
            public String saveDirLabel() {
                return Storage.saveDirLabel(LanService.this);
            }

            @Override
            public String saveUpload(InputStream in, String filename) throws IOException {
                return Storage.saveReceived(LanService.this, in, filename);
            }

            @Override
            public boolean deleteReceived(String name) {
                return Storage.deleteReceived(LanService.this, name);
            }

            @Override
            public int clearReceived() {
                return Storage.clearReceived(LanService.this);
            }

            @Override
            public InputStream openReceivedStream(String name) throws IOException {
                Uri uri = Storage.receivedContentUri(LanService.this, name);
                if (uri == null) return null;
                return getContentResolver().openInputStream(uri);
            }

            @Override
            public long receivedFileSize(String name) {
                return Storage.receivedFileSize(LanService.this, name);
            }
        });

        if (!srv.start()) {
            lastError = "端口被占用（已尝试 8080-8109），启动失败";
            shutdown();
            return;
        }
        lastError = null;
        server = srv;
        ensureForeground("http://" + getIp() + ":" + getPort());
    }

    private void shutdown() {
        if (server != null) {
            server.stop();
            server = null;
        }
        lastNotifUrl = "";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception ignored) {
        }
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, getString(R.string.chan_name), NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void ensureForeground(String urlOverride) {
        String text;
        if (urlOverride != null && !urlOverride.isEmpty()) {
            lastNotifUrl = urlOverride;
            text = urlOverride + " · 点击返回 App";
        } else if (server != null && server.isRunning()) {
            String url = "http://" + getIp() + ":" + getPort();
            lastNotifUrl = url;
            text = url + " · 点击返回 App";
        } else {
            text = getString(R.string.notif_text);
        }

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        Intent openIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        Notification notif = builder
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(Notification.PRIORITY_LOW)
                .setShowWhen(false)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }
}
