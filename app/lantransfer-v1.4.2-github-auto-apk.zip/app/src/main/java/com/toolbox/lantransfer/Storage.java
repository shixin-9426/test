package com.toolbox.lantransfer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class Storage {
    private static final String PREF = "lan_transfer_prefs";
    private static final String KEY_TREE = "save_tree_uri";
    private static final String INDEX = "received.tsv";
    private static final String RECEIVE_FOLDER = "Download/toolbot/局域网传输";

    private Storage() {}

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static Uri customTree(Context ctx) {
        try {
            String s = prefs(ctx).getString(KEY_TREE, null);
            return (s == null || s.isEmpty()) ? null : Uri.parse(s);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isCustomDir(Context ctx) {
        return customTree(ctx) != null;
    }

    public static boolean setCustomTree(Context ctx, Uri treeUri) {
        if (treeUri == null) return false;
        try {
            ctx.getContentResolver().takePersistableUriPermission(
                    treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (!canCreateInTree(ctx, treeUri)) return false;
            prefs(ctx).edit().putString(KEY_TREE, treeUri.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void clearCustomTree(Context ctx) {
        Uri cur = customTree(ctx);
        if (cur != null) {
            try {
                ctx.getContentResolver().releasePersistableUriPermission(
                        cur, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
            }
        }
        prefs(ctx).edit().remove(KEY_TREE).apply();
    }

    private static Uri treeDocumentUri(Uri treeUri) {
        String id = DocumentsContract.getTreeDocumentId(treeUri);
        return DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
    }

    private static boolean canCreateInTree(Context ctx, Uri treeUri) {
        try (Cursor c = ctx.getContentResolver().query(
                treeDocumentUri(treeUri),
                new String[]{DocumentsContract.Document.COLUMN_FLAGS},
                null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int flags = c.getInt(0);
                return (flags & DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE) != 0 || flags == 0;
            }
        } catch (Exception ignored) {
        }
        return true;
    }

    public static String saveDirLabel(Context ctx) {
        Uri tree = customTree(ctx);
        if (tree == null) return RECEIVE_FOLDER;
        String label = treeDisplayPath(tree);
        return (label == null || label.isEmpty()) ? "自选目录" : label;
    }

    private static String treeDisplayPath(Uri treeUri) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            int colon = docId.indexOf(':');
            String vol = colon > 0 ? docId.substring(0, colon) : "";
            String rel = colon >= 0 ? docId.substring(colon + 1) : docId;
            if (rel == null || rel.isEmpty()) return "存储根目录";
            boolean primary = vol.isEmpty() || "primary".equalsIgnoreCase(vol) || "home".equalsIgnoreCase(vol);
            return (primary ? "" : "SD卡/") + rel;
        } catch (Exception e) {
            return "";
        }
    }

    public static File sharedDir(Context ctx) {
        File dir = new File(ctx.getFilesDir(), "shared");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File defaultReceivedDir() {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "toolbot/局域网传输");
    }

    public static List<HttpServer.Entry> sharedEntries(Context ctx) {
        List<HttpServer.Entry> out = new ArrayList<>();
        File[] files = sharedDir(ctx).listFiles();
        if (files == null) return out;
        for (File f : files) {
            if (f.isFile() && !f.getName().startsWith(".")) {
                out.add(new HttpServer.Entry(f.getName(), f.length(), f.lastModified(), f));
            }
        }
        Collections.sort(out, new Comparator<HttpServer.Entry>() {
            @Override
            public int compare(HttpServer.Entry a, HttpServer.Entry b) {
                return Long.compare(b.time, a.time);
            }
        });
        return out;
    }

    public static int clearShared(Context ctx) {
        File[] files = sharedDir(ctx).listFiles();
        int count = 0;
        if (files != null) {
            for (File f : files) {
                if (f.isFile() && !f.getName().startsWith(".") && f.delete()) {
                    count++;
                }
            }
        }
        return count;
    }

    public static void removeShared(Context ctx, String name) {
        File dir = sharedDir(ctx);
        File target = new File(dir, name);
        try {
            File parent = target.getParentFile();
            if (parent != null && parent.getCanonicalPath().equals(dir.getCanonicalPath())) {
                target.delete();
            }
        } catch (Exception ignored) {
        }
    }

    public static String importUri(Context ctx, Uri uri) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        String name = "file";
        long expectedSize = -1;
        try (Cursor c = cr.query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex("_display_name");
                if (ni >= 0) {
                    String n = c.getString(ni);
                    if (n != null && !n.isEmpty()) name = n;
                }
                int si = c.getColumnIndex("_size");
                if (si >= 0 && !c.isNull(si)) {
                    expectedSize = c.getLong(si);
                }
            }
        }

        File target = uniqueFile(sharedDir(ctx), sanitize(name));
        long copied;
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) throw new IOException("无法读取所选文件");
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(target), 16384)) {
                copied = copy(in, out);
            }
        } catch (IOException | RuntimeException e) {
            target.delete();
            throw e;
        }

        // 修复 Bug：删除不完整文件前先记录实际写入大小，避免错误提示恒为 0/总大小
        long actualSize = target.length();
        if (expectedSize > 0 && actualSize != expectedSize) {
            target.delete();
            throw new IOException("文件复制不完整（" + actualSize + "/" + expectedSize + "），请重新添加");
        }
        return target.getName();
    }

    public static String saveReceived(Context ctx, InputStream in, String rawName) throws IOException {
        String name = sanitize(rawName);
        Uri tree = customTree(ctx);
        if (tree != null) {
            return saveToTree(ctx, tree, in, name);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return Api29.save(ctx, in, name);
        }
        return legacySave(ctx, in, name);
    }

    private static String saveToTree(Context ctx, Uri treeUri, InputStream in, String name) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        Uri parentDoc = treeDocumentUri(treeUri);
        // 修复 Bug：三次重试使用互不相同的候选文件名（原版同毫秒调用 renameAttempt 两次导致重名）
        String[] candidates = {name, renameAttempt(name, 1), renameAttempt(name, 2)};
        String[] mimes = {mimeOf(name), mimeOf(name), "application/octet-stream"};
        Uri docUri = null;
        Exception lastEx = null;
        for (int i = 0; i < candidates.length && docUri == null; i++) {
            try {
                docUri = DocumentsContract.createDocument(cr, parentDoc, mimes[i], candidates[i]);
            } catch (Exception e) {
                lastEx = e;
            }
        }
        if (docUri == null) {
            String detail = lastEx == null ? "" : "（" + lastEx.getMessage() + "）";
            throw new IOException("目标目录不可写，请在「保存位置」里重新选择" + detail);
        }

        try (OutputStream rawOut = cr.openOutputStream(docUri)) {
            if (rawOut == null) throw new IOException("无法写入所选目录");
            BufferedOutputStream bos = new BufferedOutputStream(rawOut, 16384);
            long written = copy(in, bos);
            bos.flush();
            String finalName = documentName(cr, docUri, name);
            addReceived(ctx, finalName, written);
            return finalName;
        } catch (IOException | RuntimeException e) {
            try {
                DocumentsContract.deleteDocument(cr, docUri);
            } catch (Exception ignored) {
            }
            throw e;
        }
    }

    private static String legacySave(Context ctx, InputStream in, String name) throws IOException {
        File dir = defaultReceivedDir();
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("无法创建接收目录");
        }
        File target = uniqueFile(dir, name);
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(target), 16384)) {
            copy(in, out);
        }
        MediaScannerConnection.scanFile(ctx, new String[]{target.getAbsolutePath()}, null, null);
        addReceived(ctx, target.getName(), target.length());
        return target.getName();
    }

    public static synchronized List<HttpServer.Entry> receivedEntries(Context ctx) {
        List<HttpServer.Entry> list = new ArrayList<>();
        File index = new File(ctx.getFilesDir(), INDEX);
        if (!index.isFile()) return list;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(index), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\t");
                if (p.length < 3) continue;
                try {
                    long sz = Long.parseLong(p[1]);
                    long tm = Long.parseLong(p[2]);
                    list.add(new HttpServer.Entry(p[0], sz, tm, null));
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static synchronized void addReceived(Context ctx, String name, long size) {
        List<HttpServer.Entry> old = receivedEntries(ctx);
        StringBuilder sb = new StringBuilder();
        sb.append(name).append('	').append(size).append('	').append(System.currentTimeMillis()).append('
');
        int kept = 0;
        for (HttpServer.Entry e : old) {
            if (e.name.equals(name)) continue;
            if (++kept > 80) break;
            sb.append(e.name).append('	').append(e.size).append('	').append(e.time).append('
');
        }
        writeIndex(ctx, sb.toString());
    }

    public static synchronized void removeReceivedRecord(Context ctx, String name) {
        List<HttpServer.Entry> old = receivedEntries(ctx);
        StringBuilder sb = new StringBuilder();
        for (HttpServer.Entry e : old) {
            if (e.name.equals(name)) continue;
            sb.append(e.name).append('	').append(e.size).append('	').append(e.time).append('
');
        }
        writeIndex(ctx, sb.toString());
    }

    private static void writeIndex(Context ctx, String content) {
        File index = new File(ctx.getFilesDir(), INDEX);
        try (FileOutputStream fos = new FileOutputStream(index)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    public static boolean deleteReceived(Context ctx, String name) {
        if (name == null || name.isEmpty()) return false;
        boolean exists = false;
        for (HttpServer.Entry e : receivedEntries(ctx)) {
            if (e.name.equals(name)) {
                exists = true;
                break;
            }
        }
        if (!exists) return false;
        boolean ok = false;
        Uri tree = customTree(ctx);
        if (tree != null) {
            ok |= deleteInTree(ctx, tree, name);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ok |= Api29.delete(ctx, name);
        } else {
            ok |= legacyDelete(name);
        }
        removeReceivedRecord(ctx, name);
        return ok;
    }

    public static int clearReceived(Context ctx) {
        int count = 0;
        for (HttpServer.Entry e : receivedEntries(ctx)) {
            deleteReceived(ctx, e.name);
            count++;
        }
        return count;
    }

    public static long receivedFileSize(Context ctx, String name) {
        for (HttpServer.Entry e : receivedEntries(ctx)) {
            if (e.name.equals(name)) return e.size;
        }
        return -1;
    }

    public static Uri receivedContentUri(Context ctx, String name) {
        if (name == null || name.isEmpty()) return null;
        Uri tree = customTree(ctx);
        if (tree != null) {
            Uri child = findChildInTree(ctx, tree, name);
            if (child != null) return child;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Uri media = Api29.find(ctx, name);
            if (media != null) return media;
        }
        File f = new File(defaultReceivedDir(), sanitize(name));
        if (f.isFile()) return ReceivedProvider.uriFor(f.getName());
        return null;
    }

    private static boolean legacyDelete(String name) {
        File f = new File(defaultReceivedDir(), sanitize(name));
        return f.isFile() && f.delete();
    }

    private static Uri findChildInTree(Context ctx, Uri treeUri, String displayName) {
        ContentResolver cr = ctx.getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        try (Cursor c = cr.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    if (displayName.equals(c.getString(1))) {
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(0));
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static boolean deleteInTree(Context ctx, Uri treeUri, String displayName) {
        ContentResolver cr = ctx.getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        boolean deleted = false;
        try (Cursor c = cr.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String n = c.getString(1);
                    if (n != null && n.equals(displayName)) {
                        try {
                            Uri doc = DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(0));
                            if (DocumentsContract.deleteDocument(cr, doc)) deleted = true;
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return deleted;
    }

    private static String documentName(ContentResolver cr, Uri uri, String fallback) {
        return queryName(cr, uri, fallback);
    }

    private static String queryName(ContentResolver cr, Uri uri, String fallback) {
        try (Cursor c = cr.query(uri, new String[]{"_display_name"}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) {
        }
        return fallback;
    }

    private static long querySize(ContentResolver cr, Uri uri, long fallback) {
        try (Cursor c = cr.query(uri, new String[]{"_size"}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception ignored) {
        }
        return fallback;
    }

    private static String renameAttempt(String name, int seq) {
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        return stem + " (" + (System.currentTimeMillis() % 100000L) + "_" + seq + ")" + ext;
    }

    public static String sanitize(String name) {
        if (name == null) return "file";
        String s = name.replace('\\', '/');
        int slash = s.lastIndexOf('/');
        if (slash >= 0) s = s.substring(slash + 1);
        s = s.replaceAll("[\\r\\n\\t\\u0000-\\u001f]", "").trim();
        if (s.isEmpty() || ".".equals(s) || "..".equals(s)) s = "file";
        if (s.length() > 120) {
            int dot = s.lastIndexOf('.');
            String ext = (dot > 0 && dot > s.length() - 12) ? s.substring(dot) : "";
            s = s.substring(0, 110) + ext;
        }
        return s;
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            File cand = new File(dir, stem + " (" + i + ")" + ext);
            if (!cand.exists()) return cand;
        }
        return new File(dir, System.currentTimeMillis() + "_" + name);
    }

    public static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        String ext = dot >= 0 ? name.substring(dot + 1).toLowerCase(Locale.US) : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return mime != null ? mime : "application/octet-stream";
    }

    public static String sizeText(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024));
        return String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    private static long copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384];
        long total = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            total += n;
        }
        return total;
    }

    private static final class Api29 {
        static String save(Context ctx, InputStream in, String name) throws IOException {
            ContentResolver cr = ctx.getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name));
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, RECEIVE_FOLDER);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("无法创建接收文件");
            try {
                long written;
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) throw new IOException("无法写入接收目录");
                    BufferedOutputStream bos = new BufferedOutputStream(os, 16384);
                    written = copy(in, bos);
                    bos.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, done, null, null);
                String finalName = queryName(cr, uri, name);
                long finalSize = querySize(cr, uri, written);
                addReceived(ctx, finalName, finalSize);
                return finalName;
            } catch (IOException | RuntimeException e) {
                cr.delete(uri, null, null);
                throw e;
            }
        }

        static Uri find(Context ctx, String displayName) {
            try (Cursor c = ctx.getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.MediaColumns._ID},
                    "(relative_path = ? OR relative_path LIKE ?) AND _display_name = ?",
                    new String[]{RECEIVE_FOLDER, RECEIVE_FOLDER + "/%", displayName},
                    null)) {
                if (c != null && c.moveToFirst()) {
                    return ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0));
                }
            } catch (Exception ignored) {
            }
            return null;
        }

        static boolean delete(Context ctx, String displayName) {
            try {
                int n = ctx.getContentResolver().delete(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        "(relative_path = ? OR relative_path LIKE ?) AND _display_name = ?",
                        new String[]{RECEIVE_FOLDER, RECEIVE_FOLDER + "/%", displayName});
                return n > 0;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
